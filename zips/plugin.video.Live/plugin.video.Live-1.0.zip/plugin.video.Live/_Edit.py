import xbmcaddon

MainBase = 'http://ledtvonline.net/tv/home.txt'
addon = xbmcaddon.Addon('plugin.video.Live')
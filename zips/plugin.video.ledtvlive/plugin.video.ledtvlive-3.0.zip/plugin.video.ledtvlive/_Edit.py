import xbmcaddon

MainBase = 'http://alturl.com/22gip'
addon = xbmcaddon.Addon('plugin.video.ledtvlive')
